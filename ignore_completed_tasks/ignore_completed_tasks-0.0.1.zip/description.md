
---

##### Links:

- [Support](https://unmanic.app/discord)
- [Issues/Feature Requests](https://github.com/Unmanic/plugin.ignore_completed_tasks/issues)
- [Pull Requests](https://github.com/Unmanic/plugin.ignore_completed_tasks/pulls)
